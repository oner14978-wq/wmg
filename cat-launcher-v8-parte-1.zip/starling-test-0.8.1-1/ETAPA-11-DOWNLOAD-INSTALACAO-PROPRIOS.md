# ETAPA 11 - download, instalação e versões próprios - NÃO COMPILADO, NÃO TESTADO NO APARELHO

Validado aqui só: sintaxe do JS, e uma simulação em Node das fases do download/preparo com um motor de mentira
(a versão só vira "instalada" quando o motor diz installed=true, ou seja, depois do preparo). Rust/Java NÃO compilados.

## Responsabilidades
- DOWNLOAD: accounts::download_files (Mojang, hash por arquivo). Bytes/arquivos reais; velocidade calculada na página pelos bytes reais (janela de 4 s). Cancelar: cancel_download.
- INSTALAÇÃO: cat_bridge.rs `install()` = download + preparer::start (Java + horizon-prepare) numa thread que continua mesmo se a tela for fechada.
  "Instalada" = arquivos prontos E resources/assets/minecraft/sounds.json existe E preparo não está rodando (`installed()`).
  Preparo no processo do launcher: hook `asset` agora lê o APK via CatCore.asset (antes devolvia None e o kit não abriria).
- JOGAR: só roda versão instalada. Se não estiver, avisa e abre DOWNLOAD DE VERSÕES. Depois, a tela roxa (ETAPA 10) acompanha o início real.

## Telas (index.html)
- Início próprio (sem a imagem de fundo com botões invisíveis): cartões das versões instaladas (nome, número, estado, JOGAR, ⚙, remover) + DOWNLOAD DE VERSÕES.
- DOWNLOAD DE VERSÕES: lista, informações, BAIXAR E INSTALAR, progresso, velocidade, tamanho, arquivos, cancelar, aviso ao terminar.
- A tela antiga "vers" continua no arquivo, mas go('vers') agora abre a nova.

## Limites reais
- O motor só roda o Minecraft 26.3: a lista tem uma versão.
- O preparo não informa porcentagem nem pode ser cancelado: a tela mostra o passo e o tempo.
- Remover apaga arquivos do jogo e recursos preparados; mundos e configurações ficam.
- ⚙ mostra informações; o motor não tem configurações por versão (vídeo/som ficam no menu do jogo).
- Os menus do jogo (pesca, escolha de conta/login) são do Starling e não foram redesenhados.

## Checar no primeiro build
1. resources() (game_home/resources) igual ao que o jogo usa (android.rs command_line / game_folder).
2. unpack_kit/preparer rodando no processo :cat (kit via CatCore.asset; libstarling_java.so via libraryDir).
3. Instalar até o fim, JOGAR, tela roxa, entrar. adb logcat -s starling:* chromium:* AndroidRuntime:E
