# ETAPA 9 — "Preparing the game" parada

## Diagnóstico (só leitura de código; NADA foi executado)
- A linha "Wrote the world generator's bundle in 0.8 s" é o último log de UMA faixa rápida de horizon-prepare/lib.rs (`files`).
  As outras faixas (JVMs exportadores do servidor/cliente/reports/blocos, lib.rs ~1100-1320) rodam em paralelo, sem log durante minutos.
  Logo a tela pode estar trabalhando, travada num exportador, ou o Java pode ter caído; só o log distingue.
- Falha de verdade já vira `Stage::Failed` (mensagem na tela). Travar de verdade = JVM viva e parada (timeout de 1 h em java.rs/worker.rs).
- Cadeia no aparelho (preparer.rs): baixa JRE 25 -> libstarling_java.so/javac.so (java_launcher.c, JLI_Launch) -> exportadores. Não achei defeito evidente.

## Mudança feita (Rust, NÃO compilado)
- preparer.rs: `Heartbeat` mostra na tela o último passo + tempo total + "no new step for N min" (após 10 min sem passo novo).

## Para achar a causa real (preciso do resultado)
    adb logcat -s starling:* AndroidRuntime:E > log.txt
    e os *.log do preparo (export.log, *-worker.log, creative-export.log) na pasta privada do app (preparer/kit/.local).
